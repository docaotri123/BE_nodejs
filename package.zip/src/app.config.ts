export const SERVER_HOST = '0.0.0.0';
export const SERVER_PORT = process.env.PORT || 3000;
export const SECRET = 'Hotel@@';
