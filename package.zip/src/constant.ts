export const ROLE = {
    ADMIN : 'admin',
    CUSTOMER: 'customer'
};

export const HASH_STR = 'HOTEL';
