export class UserModel {
    Email: string;
    Phone: string;
    Password: string;
    Role: string;
}
