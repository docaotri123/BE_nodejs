export class LoginModel {
    Username: string;
    Password: string;
}
