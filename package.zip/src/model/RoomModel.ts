export class RoomModel {
    description: string;
    image: string;
    quality: number;
    price: number;
    type: string;
}
