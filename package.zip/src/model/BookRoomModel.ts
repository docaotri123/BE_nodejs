export class BookRoomModel {
    startDate: Date;
    endDate: Date;
    userId: string;
}
